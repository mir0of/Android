package com.example.gyrorush

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Entry activity hosting the GyroRush game.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GyroRushGame()
        }
    }
}

/**
 * The control mode used by the game. TILT uses the rotation vector sensor (based on gyroscope,
 * accelerometer and magnetometer) to compute device orientation. GYRO uses the raw gyroscope
 * angular velocity to control velocity directly.
 */
enum class ControlMode { TILT, GYRO }

/**
 * A composable that draws and updates the game. It sets up sensor listeners according to
 * the currently selected control mode, spawns obstacles and coins at intervals, handles
 * collisions, scoring and game over, and draws everything on a Canvas. Double tap to toggle
 * between TILT and GYRO modes; tap when game is over to restart.
 */
@Composable
fun GyroRushGame() {
    val context = LocalContext.current
    val sensorManager = remember { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val rotationSensor = remember { sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) }
    val gyroSensor = remember { sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) }

    var mode by remember { mutableStateOf(ControlMode.TILT) }

    // Game state: ball position and velocity
    var ballX by remember { mutableStateOf(0f) }
    var ballY by remember { mutableStateOf(0f) }
    var ballVX by remember { mutableStateOf(0f) }
    var ballVY by remember { mutableStateOf(0f) }
    val ballRadius = 40f // pixels; adjust for your device density if desired

    // Dynamic lists for obstacles and coins
    val obstacles = remember { mutableStateListOf<Obstacle>() }
    val coins = remember { mutableStateListOf<Coin>() }

    var lives by remember { mutableStateOf(3) }
    var score by remember { mutableStateOf(0) }
    var gameOver by remember { mutableStateOf(false) }

    val vibrator = remember { context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator }

    var lastSpawnTime by remember { mutableStateOf(0L) }
    val spawnInterval = 1500L // milliseconds

    // Determine screen size using display metrics; fixed for simplicity
    val displayMetrics = context.resources.displayMetrics
    val screenWidth = displayMetrics.widthPixels.toFloat()
    val screenHeight = displayMetrics.heightPixels.toFloat()

    // Sensor event listener registration and deregistration based on control mode
    DisposableEffect(mode) {
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event ?: return
                if (mode == ControlMode.TILT && event.sensor.type == Sensor.TYPE_GAME_ROTATION_VECTOR) {
                    // Convert rotation vector to roll/pitch to compute acceleration
                    val rotationMatrix = FloatArray(9)
                    SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                    val remapped = FloatArray(9)
                    // Remap the coordinate system so that the device's X axis points right and Z points up
                    SensorManager.remapCoordinateSystem(
                        rotationMatrix,
                        SensorManager.AXIS_X,
                        SensorManager.AXIS_Z,
                        remapped
                    )
                    val orientations = FloatArray(3)
                    SensorManager.getOrientation(remapped, orientations)
                    val roll = orientations[2] // rotation around the forward axis (tilt left/right)
                    val pitch = orientations[1] // rotation around the right axis (tilt forward/backward)
                    // Map roll/pitch to acceleration; negative to invert intuitive direction
                    ballVX += (-roll).toFloat() * 0.5f
                    ballVY += pitch.toFloat() * 0.5f
                } else if (mode == ControlMode.GYRO && event.sensor.type == Sensor.TYPE_GYROSCOPE) {
                    // Integrate angular velocity to velocity increments; scale factor chosen empirically
                    ballVX += event.values[1] * 20f
                    ballVY += -event.values[0] * 20f
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (mode == ControlMode.TILT) {
            sensorManager.registerListener(listener, rotationSensor, SensorManager.SENSOR_DELAY_GAME)
        } else {
            sensorManager.registerListener(listener, gyroSensor, SensorManager.SENSOR_DELAY_GAME)
        }
        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    // Main game loop; runs at ~60 FPS
    LaunchedEffect(Unit) {
        // Initialize ball in center
        ballX = screenWidth / 2f
        ballY = screenHeight / 2f
        while (true) {
            val dt = 1f / 60f

            if (!gameOver) {
                // Update position using velocity
                ballX += ballVX
                ballY += ballVY

                // Apply simple friction to damp velocity
                ballVX *= 0.98f
                ballVY *= 0.98f

                // Keep ball within screen; bounce off edges
                if (ballX - ballRadius < 0f) {
                    ballX = ballRadius
                    ballVX = -ballVX * 0.6f
                } else if (ballX + ballRadius > screenWidth) {
                    ballX = screenWidth - ballRadius
                    ballVX = -ballVX * 0.6f
                }
                if (ballY - ballRadius < 0f) {
                    ballY = ballRadius
                    ballVY = -ballVY * 0.6f
                } else if (ballY + ballRadius > screenHeight) {
                    ballY = screenHeight - ballRadius
                    ballVY = -ballVY * 0.6f
                }

                // Spawn obstacles and coins periodically
                val now = System.currentTimeMillis()
                if (now - lastSpawnTime > spawnInterval) {
                    lastSpawnTime = now
                    val obsWidth = screenWidth * (0.1f + Random.nextFloat() * 0.2f)
                    val obsHeight = screenHeight * 0.02f
                    val xPos = Random.nextFloat() * (screenWidth - obsWidth)
                    val speed = screenHeight * (0.1f + Random.nextFloat() * 0.15f)
                    obstacles += Obstacle(xPos, -obsHeight, obsWidth, obsHeight, speed)
                    // 40% chance to spawn a coin
                    if (Random.nextFloat() < 0.4f) {
                        val cx = Random.nextFloat() * (screenWidth - 2f * ballRadius) + ballRadius
                        val cy = -obsHeight - ballRadius * 2f
                        coins += Coin(cx, cy, ballRadius * 0.5f)
                    }
                }

                // Update obstacles; remove if off-screen; check collisions
                val obsIter = obstacles.iterator()
                while (obsIter.hasNext()) {
                    val ob = obsIter.next()
                    ob.y += ob.speed * dt
                    if (ob.y > screenHeight) {
                        obsIter.remove()
                        continue
                    }
                    // Ball-rect collision detection
                    if (ballX + ballRadius > ob.x && ballX - ballRadius < ob.x + ob.width &&
                        ballY + ballRadius > ob.y && ballY - ballRadius < ob.y + ob.height) {
                        lives -= 1
                        vibrator.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE))
                        obsIter.remove()
                        if (lives <= 0) {
                            gameOver = true
                        }
                    }
                }

                // Update coins; remove if off-screen; check collisions
                val coinIter = coins.iterator()
                while (coinIter.hasNext()) {
                    val coin = coinIter.next()
                    coin.y += (screenHeight * 0.08f) * dt
                    if (coin.y > screenHeight) {
                        coinIter.remove()
                        continue
                    }
                    val dx = ballX - coin.x
                    val dy = ballY - coin.y
                    val dist = sqrt(dx * dx + dy * dy)
                    if (dist < ballRadius + coin.radius) {
                        score += 10
                        vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
                        coinIter.remove()
                    }
                }
            }
            delay((dt * 1000).toLong())
        }
    }

    // UI layer: draw game and overlay info
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(mode, lives, gameOver) {
                detectTapGestures(
                    onDoubleTap = {
                        // Toggle control mode on double tap
                        mode = if (mode == ControlMode.TILT) ControlMode.GYRO else ControlMode.TILT
                    },
                    onTap = {
                        // Restart when game over
                        if (gameOver) {
                            lives = 3
                            score = 0
                            gameOver = false
                            ballX = screenWidth / 2f
                            ballY = screenHeight / 2f
                            ballVX = 0f
                            ballVY = 0f
                            obstacles.clear()
                            coins.clear()
                        }
                    }
                )
            }
    ) {
        // Draw game elements
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Ball
            drawCircle(color = Color.Cyan, radius = ballRadius, center = Offset(ballX, ballY))
            // Obstacles
            obstacles.forEach { ob ->
                drawRect(
                    color = Color.Red,
                    topLeft = Offset(ob.x, ob.y),
                    size = androidx.compose.ui.geometry.Size(ob.width, ob.height)
                )
            }
            // Coins
            coins.forEach { coin ->
                drawCircle(
                    color = Color.Yellow,
                    radius = coin.radius,
                    center = Offset(coin.x, coin.y)
                )
            }
        }
        // HUD
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Score: $score", color = Color.White)
            Text(text = "Lives: $lives", color = Color.White)
            Text(text = "Mode: ${if (mode == ControlMode.TILT) "TILT" else "GYRO"}", color = Color.White)
            if (gameOver) {
                Text(text = "Game Over! Tap to restart.", color = Color.White, modifier = Modifier.padding(top = 16.dp))
            }
        }
    }
}

/** Data class representing a rectangular obstacle. */
data class Obstacle(var x: Float, var y: Float, val width: Float, val height: Float, val speed: Float)

/** Data class representing a collectible coin. */
data class Coin(var x: Float, var y: Float, val radius: Float)