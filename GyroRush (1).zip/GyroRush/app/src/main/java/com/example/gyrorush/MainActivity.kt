package com.example.gyrorush

import android.content.Context
import android.hardware.*
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.android.awaitFrame
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme { Surface(Modifier.fillMaxSize()) { GameScreen() } }
        }
    }
}

// ---------- Gestion Sons légers via SoundPool ----------
class Sfx(context: Context) {
    private val soundPool = android.media.SoundPool.Builder().setMaxStreams(3).build()
    private val idCoin = try { soundPool.load(context, R.raw.coin, 1) } catch (_: Exception){ 0 }
    private val idHit = try { soundPool.load(context, R.raw.hit, 1) } catch (_: Exception){ 0 }
    fun coin() { if (idCoin!=0) soundPool.play(idCoin,1f,1f,1,0,1f) }
    fun hit() { if (idHit!=0) soundPool.play(idHit,1f,1f,1,0,1f) }
}

// ---------- Capteurs ----------
class Sensors(context: Context) : SensorEventListener {
    private val mgr = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rot = mgr.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
    private val gyro = mgr.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    // Tilt (rotation vector)
    var tiltX by mutableStateOf(0f); private set // roll
    var tiltY by mutableStateOf(0f); private set // pitch

    // Gyro (rad/s)
    var gyroX by mutableStateOf(0f); private set
    var gyroY by mutableStateOf(0f); private set

    fun start() {
        rot?.let { mgr.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        gyro?.let { mgr.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }
    fun stop() { mgr.unregisterListener(this) }

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_GAME_ROTATION_VECTOR -> {
                val Rm = FloatArray(9)
                SensorManager.getRotationMatrixFromVector(Rm, e.values)
                val o = FloatArray(3)
                SensorManager.getOrientation(Rm, o)
                tiltY = o[1] // pitch
                tiltX = o[2] // roll
            }
            Sensor.TYPE_GYROSCOPE -> {
                gyroX = e.values[0]; gyroY = e.values[1]
            }
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

@Composable
fun rememberSensors(): Sensors {
    val ctx = LocalContext.current
    val s = remember { Sensors(ctx) }
    DisposableEffect(Unit) { s.start(); onDispose { s.stop() } }
    return s
}

// ---------- Modèle de jeu ----------
data class Obstacle(var rect: Rect, var speed: Float)
data class Coin(var pos: Offset, val r: Float, var taken: Boolean=false)

enum class ControlMode { TILT, SHIP }

@Composable
fun GameScreen() {
    val cfg = LocalConfiguration.current
    val wDp = cfg.screenWidthDp.dp
    val hDp = cfg.screenHeightDp.dp
    val ctx = LocalContext.current
    val sensors = rememberSensors()
    val sfx = remember { Sfx(ctx) }
    val vibrator = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    var mode by remember { mutableStateOf(ControlMode.TILT) }
    var started by remember { mutableStateOf(false) }
    var gameOver by remember { mutableStateOf(false) }

    // Joueur
    var pos by remember { mutableStateOf(Offset(200f, 1200f)) }
    var vel by remember { mutableStateOf(Offset.Zero) }
    val radius = 28f
    var lives by remember { mutableStateOf(3) }

    // Monde
    val obstacles = remember { mutableStateListOf<Obstacle>() }
    val coins = remember { mutableStateListOf<Coin>() }
    var spawnTimer by remember { mutableStateOf(0f) }
    var score by remember { mutableStateOf(0) }
    var timeSurvive by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val t = awaitFrame()
            if (last==0L) { last = t; continue }
            val dt = (t-last)/1_000_000_000f
            last = t

            if (started && !gameOver) {
                val wPx = ctx.dpToPx(wDp)
                val hPx = ctx.dpToPx(hDp)

                // --- Contrôles ---
                when (mode) {
                    ControlMode.TILT -> {
                        val gx = (-sensors.tiltX).coerceIn(-1.2f,1.2f)
                        val gy = (sensors.tiltY).coerceIn(-1.2f,1.2f)
                        val accel = Offset(gx, gy) * 1400f
                        vel += accel * dt
                        vel *= 0.90f
                    }
                    ControlMode.SHIP -> {
                        val ax = (-sensors.gyroY) * 900f
                        val ay = (sensors.gyroX) * 900f
                        vel += Offset(ax, ay) * dt
                        vel *= 0.92f
                    }
                }
                // Clamps et déplacement
                val maxV = 1400f
                vel = Offset(vel.x.coerceIn(-maxV,maxV), vel.y.coerceIn(-maxV,maxV))
                pos += vel * dt
                pos = Offset(
                    pos.x.coerceIn(radius, wPx - radius),
                    pos.y.coerceIn(radius, hPx - radius)
                )

                // --- Spawns dynamiques ---
                spawnTimer += dt
                if (spawnTimer > max(0.5f, 1.2f - timeSurvive*0.02f)) {
                    spawnTimer = 0f
                    // Obstacle horizontal qui descend
                    val ow = kotlin.random.Random.nextFloat() * (wPx*0.45f) + wPx*0.25f
                    val ox = kotlin.random.Random.nextFloat() * (wPx - ow)
                    val speed = kotlin.random.Random.nextFloat()*220f + 260f + timeSurvive*6f
                    obstacles += Obstacle(Rect(ox, -40f, ox+ow, 10f), speed)
                    // Pièce au hasard
                    if (kotlin.random.Random.nextFloat() < 0.6f) {
                        val cx = kotlin.random.Random.nextFloat()*(wPx-80f)+40f
                        coins += Coin(Offset(cx, -20f), 14f)
                    }
                }
                // Mise à jour obstacles/coins
                val itObs = obstacles.iterator()
                while (itObs.hasNext()) {
                    val ob = itObs.next()
                    ob.rect = Rect(ob.rect.left, ob.rect.top + ob.speed*dt, ob.rect.right, ob.rect.bottom + ob.speed*dt)
                    if (ob.rect.top > hPx+20f) itObs.remove()
                    if (circleRectCollides(pos, radius, ob.rect)) {
                        lives -= 1; sfx.hit(); vibrate(vibrator)
                        itObs.remove()
                        if (lives <= 0) gameOver = true
                    }
                }
                val itCoins = coins.iterator()
                while (itCoins.hasNext()) {
                    val c = itCoins.next()
                    val ny = c.pos.y + 240f*dt
                    val nc = c.copy(pos = Offset(c.pos.x, ny))
                    if (distance2(nc.pos, pos) <= (nc.r+radius)*(nc.r+radius)) {
                        score += 1; sfx.coin(); itCoins.remove(); continue
                    }
                    if (ny > hPx + 30f) itCoins.remove() else {
                        c.pos = nc.pos
                    }
                }

                // Score temps
                timeSurvive += dt
            }
        }
    }

    fun reset() {
        obstacles.clear(); coins.clear()
        lives = 3; score = 0; timeSurvive = 0f
        pos = Offset(200f, 1200f); vel = Offset.Zero
        started = true; gameOver = false
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF0B0F1A))) {
        // HUD haut
        Text(
            text = "Score: $score  |  Vies: $lives  |  Mode: ${if (mode==ControlMode.TILT) "TILT" else "VAISSEAU"}",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 24.dp)
        )

        // Zone de jeu
        Canvas(
            modifier = Modifier.fillMaxSize().pointerInput(mode, started, gameOver) {
                detectTapGestures(
                    onTap = { if (!started || gameOver) reset() },
                    onDoubleTap = { mode = if (mode==ControlMode.TILT) ControlMode.SHIP else ControlMode.TILT }
                )
            }
        ) {
            val w = size.width; val h = size.height

            // Dessin obstacles
            obstacles.forEach { ob ->
                drawRect(Color(0xFFE53935), topLeft = ob.rect.topLeft, size = ob.rect.size)
            }
            // Dessin pièces
            coins.forEach { c ->
                drawCircle(Color(0xFFFFD740), radius = c.r, center = c.pos)
            }
            // Joueur
            drawCircle(if (!gameOver) Color(0xFF42A5F5) else Color(0xFFFFC107), radius = radius, center = pos)

            if (!started) {
                drawTextCentered("Appuyez pour démarrer — Double‑tap pour changer de mode", w, h)
            } else if (gameOver) {
                drawTextCentered("Game Over — Appuyez pour rejouer", w, h)
            }
        }

        // Astuces
        Text(
            text = "Inclinez / tournez le téléphone. Double‑tap: changer de mode.",
            color = Color(0xFFB0BEC5), fontSize = 14.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp)
        )
    }
}

// --------- Helpers dessin/physique ---------
fun Context.dpToPx(dp: androidx.compose.ui.unit.Dp): Float = resources.displayMetrics.density * dp.value

fun circleRectCollides(c: Offset, r: Float, rect: Rect): Boolean {
    val nx = c.x.coerceIn(rect.left, rect.right)
    val ny = c.y.coerceIn(rect.top, rect.bottom)
    val dx = c.x - nx; val dy = c.y - ny
    return dx*dx + dy*dy <= r*r
}

fun distance2(a: Offset, b: Offset): Float {
    val dx = a.x - b.x; val dy = a.y - b.y; return dx*dx + dy*dy
}

@androidx.compose.ui.graphics.drawscope.DrawScopeMarker
fun androidx.compose.ui.graphics.drawscope.DrawScope.drawTextCentered(text: String, w: Float, h: Float) {
    drawContext.canvas.nativeCanvas.apply {
        val p = android.graphics.Paint().apply {
            color = android.graphics.Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            textSize = 40f
            isAntiAlias = true
        }
        drawText(text, w/2f, h/2f, p)
    }
}

fun vibrate(v: Vibrator) {
    try { v.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_: Exception) {}
}
